# -*- coding: utf-8 -*-
"""Project metadata

Information describing the project.
"""

# The package name, which is also the "UNIX name" for the project.
package = 'slsdk'
project = "REST SDK"
project_no_spaces = project.replace(' ', '')
version = '0.2'
description = 'Sparkling Logic REST SDK for Python'
authors = ['Sparkling Logic']
authors_string = ', '.join(authors)
emails = ['info@sparklinglogic.com']
license = 'MIT'
copyright = '2018 ' + authors_string
url = 'http://www.sparklinglogic.com/'

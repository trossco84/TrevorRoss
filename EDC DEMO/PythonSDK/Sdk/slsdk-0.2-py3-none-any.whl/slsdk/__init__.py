# -*- coding: utf-8 -*-
"""Sparkling Logic REST SDK for Python"""

from slsdk import metadata


__version__ = metadata.version
__author__ = metadata.authors[0]
__license__ = metadata.license
__copyright__ = metadata.copyright


class SlRestDeploymentRequest:
    """ Abstract base class for all RESTfull requests

    -   Attributes:

        operationId: integer

        Operation ID for correlation purposes.

    """

    __operationId = 0

    def __init__(self):
        self.__id = 0

    @property
    def operationId(self):
        if (self.__id == 0):
            self.__id = SlRestDeploymentRequest.__operationId = SlRestDeploymentRequest.__operationId + 1
        return self.__id

    @operationId.setter
    def operationId(self, value):
        self.__id = value


class SlRestDeploymentConnectionRequest(SlRestDeploymentRequest):
    """ Context information for a request to establish a connection to a decision deployment service.

    -   Attributes:

        username: string
        password: string
        workspaceId: string
        deploymentId: string
        deploymentReleaseId: string
        metricCategory: integer (Default: 0)
    """

    def __init__(self, username, password, workspace, deploymentId):
        SlRestDeploymentRequest.__init__(self)
        self.username = username
        self.password = password
        self.workspaceId = workspace
        self.deploymentId = deploymentId
        self.deploymentReleaseId = None
        self.metricCategory = 0


class SlRestDeploymentAccessTokenRequest(SlRestDeploymentConnectionRequest):
    """  Context information for a request to obtain an access token for a decision deployment service."""
    pass


class SlRestDeploymentDisconnectionRequest(SlRestDeploymentRequest):
    """ Context information for disconnecting from a decision deployment service

    -   Attributes:

        sessionId: string
        The session ID for which of the connection to be closed.
    """
    def __init__(self, sessionId):
        SlRestDeploymentRequest.__init__(self)
        self.sessionId = sessionId


class SlRestDecisionEvaluationRequest(SlRestDeploymentRequest):
    """Context information for a request to evaluate a decision.

    -   Attributes:
        sessionId: string
        The session ID for this evaluation request. The session ID must be obtained through a DeploymentConnectionRequest.
        Required for session based evalution requests. Must be left undefined for token based evaluation requests.

        accessToken: SlRestDeploymentAccessToken
        The access token for this evaluation request.

        decisionId: string
        Identifies the decision to use for this evaluation request.
        The decision must be part of the deployment for the session associated with this request.

        options: SlRestDecisionEvaluationOptions
        Options for the decision evaluation

        documents: Array of json documents
        The documents to evaluate the decision on.
        The contents must be a JSON object or an array of JSON objects.

    """

    def __init__(self, sessionId, accessToken, decisionId):
        SlRestDeploymentRequest.__init__(self)
        self.sessionId = sessionId
        self.accessToken = accessToken
        self.decisionId = decisionId
        self.options = None
        self.documents = None


class SlRestDecisionEvaluationOptions:
    """ Additional options for evaluation of a decision.

    -   Attributes:

        omitDefaultValues; boolean (Default: False)
        Whether or not to omit default values in the response.
        By default all provided input and all fields used by the decision is returned in the response.
        This option will remove empty arrays and fields not used (and not provided as input) from the response
        thereby reducing the size of the response. Typically used when there are many optional data sections.

    """

    def __init__(self):
        self.omitDefaultValues = False


class SlRestTaskFlowRequest(SlRestDeploymentRequest):
    """ Context information for interaction with the taskflow service

    -   Attributes:

        sessionId: string
        The session ID for this execution request. The session ID must be obtained through a DeploymentConnectionRequest
        taskflowId: string
        Id of the created task flow

    """

    def __init__(self, sessionId, taskflowId):
        SlRestDeploymentRequest.__init__(self)
        self.sessionId = sessionId
        self.taskflowId = taskflowId


class SlRestTaskFlowExecutionRequest(SlRestTaskFlowRequest):
    """ Context information for a request to trigger a taskflow execution.

    -   Attributes:

        stateMachineName: string
        The State machine name

        taskflowDescription: string
        Task flow execution description

        documents: Array of JSON object
        Optional for taskflows that require document processing.

        configs: Array of taskflow configurations
        Tasks configurations

    """

    def __init__(self, sessionId, stateMachineName):
        SlRestTaskFlowRequest.__init__(self, sessionId, None)
        self.stateMachineName = stateMachineName
        self.taskflowDescription = None
        self.documents = None
        self.configs = None


class SlRestTaskFlowUpdateRequest(SlRestTaskFlowRequest):
    """ Context information for a request to update a running taskflow.

    -   Attributes:

        config: Task Configuration

    """

    def __init__(self, sessionId, taskflowId):
        SlRestTaskFlowRequest.__init__(self, sessionId, taskflowId)
        self.config = None

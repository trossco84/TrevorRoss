from slsdk.rest.utils import SlRestUtils
from slsdk.rest.client import OAuthResponse
from slsdk.rest.client import SlRestDeploymentAccessTokenResponse
from slsdk.rest.client import SlRestDeploymentConnectionRequest
from slsdk.rest.client import SlRestDeploymentConnectionResponse
from slsdk.rest.client import SlRestDeploymentDisconnectionResponse
from slsdk.rest.client import SlRestDecisionEvaluationResponse
from slsdk.rest.client import SlRestDecisionEvaluationRequest
from slsdk.rest.client import SlRestTaskFlowExecutionRequest
from slsdk.rest.client import SlRestTaskFlowExecutionResponse
from slsdk.rest.client import SlRestTaskFlowUpdateRequest
from slsdk.rest.client import SlRestTaskFlowResponse
from slsdk.rest.client import SlRestTaskFlowResultsResponse
import requests
from requests.exceptions import HTTPError
import json


class SlRestClientConfig:
    """ Configuration options for the SlRestClient.

    -   Attributes

        serviceUrl: string
        The URL of the REST Service for the client to use.

        forwardedHost: boolean (default False)
        Indicator whether the REST services is accessed through port forwarding

        allowCertificateValidationErrors: boolean (default True)
        Indicator whether certificate error are allowed. This allows for the use of self-signed certificates.

    """

    def __init__(self, serviceUrl):
        """Construct an instance of a configuration class

        -   Parameters

            serviceUrl: string
            The URL of the REST Service for the client to use.

        """
        self.serviceUrl = serviceUrl
        self.forwardedHost = False
        self.allowCertificateValidationErrors = True


class SlCredentials:

    def __init__(self, accessId, key):
        self.accessId = accessId
        self.key = key


class SlAbstractRestClient:
    """ Abstract base classe for RESTful client interactions."""

    def __init__(self, config, accessId, accessKey):
        """ Construct an instance of the client class.
        -   Parameters:
            config: SlRestClientConfig
            accessId: string
            accessKey: string
        """
        self.config = config
        self._credentials = SlCredentials(accessId, accessKey)

    def _addCommonParameters(self, parameters):
        parameters['appId'] = self._credentials.accessId

    def _addRequiredParameters(self, method, parameters, queueUrl):
        self._addCommonParameters(parameters)
        parameters['reqTime'] = SlRestUtils.getFormattedCurrentTimestampISO8601()
        host = SlRestUtils.getAuthority(queueUrl)
        endpoint = SlRestUtils.getEndpoint(queueUrl)
        SlRestUtils.signQueryParameters(method, host, endpoint, self._credentials.key, parameters)

    def _invoke(self, method, resource, parameters):
        queueUrl = self.config.serviceUrl + "/" + resource
        if ('sign' in parameters):
            del parameters['sign']
        self._addRequiredParameters(method, parameters, queueUrl)
        verify = self.config.allowCertificateValidationErrors is False
        headers = dict()
        if self.config.forwardedHost is True:
            headers['X-Forwarded-Host'] = SlRestUtils.getAuthority(self.config.serviceUrl)
        r = self.postRequest(queueUrl, parameters, headers, verify)
        if r.status_code != requests.codes.ok:
            r.raise_for_status()
        return r.json()

    def _invokeHealthCheck(self, method, resource, parameters):
        queueUrl = self.config.serviceUrl + "/" + resource
        if ('sign' in parameters):
            del parameters['sign']
        host = SlRestUtils.getAuthority(queueUrl)
        endpoint = SlRestUtils.getEndpoint(queueUrl)
        SlRestUtils.signQueryParameters(method, host, endpoint, self._credentials.key, parameters)

        verify = self.config.allowCertificateValidationErrors is False
        headers = dict()
        if self.config.forwardedHost is True:
            headers['X-Forwarded-Host'] = SlRestUtils.getAuthority(self.config.serviceUrl)
        r = self.getRequest(queueUrl, parameters, headers, verify)
        return r.status_code

    def _handleResponseStatus(self, response, result):
        if ('OperationId' in result):
            response.operationId = result['OperationId']

        if ('Success' in result):
            response.success = result['Success'] is True
        else:
            response.success = False

        if ('ErrorInfo' in result and result['ErrorInfo'] is not None):
            errorInfo = result['ErrorInfo']
            response.errorCode = errorInfo['ErrorCode']
            response.errorMessage = errorInfo['ErrorMessage']
            response.details = errorInfo['Details']

    def _getBaseAuthenticationTag(self, id):
        return SlRestUtils.getBaseAuthenticationTag(self._credentials.accessId, self._credentials.key.encode('utf-8'), id.encode('utf-8'))

    def postRequest(self, url, data, headers, verify):
        """ POST a RESTful request to the server
            Override this method if you want to provide additional header or have other requests.post configuration
            requirements
        """
        return requests.post(url, data=data, headers=headers, verify=verify)

    def getRequest(self, url, parameters, headers, verify):
        """ GET a RESTful request from the server
            Override this method if you want to provide additional header or have other requests.post configuration
            requirements
        """
        return requests.get(url, params=parameters, headers=headers, verify=verify)


class SlRestAuthClient(SlAbstractRestClient):
    """  OAuth client for interaction with the authentication service.

    Use this class or one of its subclasses to obtain secure access tokens from the authentication service.
    """

    def _getAuthServiceUrl(self):
        return self.config.serviceUrl.replace("http://", "https://").replace("DecisionServer/decision-services", "AuthServer").replace(":19732", ":44332")

    def _invokeAuth(self, resource, parameters, authTag):
        queueUrl = self._getAuthServiceUrl() + "/" + resource
        headers = {"Authorization": str.format("Basic {0}", authTag)}
        verify = self.config.allowCertificateValidationErrors is False
        if self.config.forwardedHost is True:
            headers['X-Forwarded-Host'] = SlRestUtils.getAuthority(self.config.serviceUrl)
        r = self.postRequest(queueUrl, parameters, headers, verify)
        if r.status_code != requests.codes.ok:
            r.raise_for_status()
        return r.json()

    def _unwrap(self, source):
        if (source.id_token is None or len(source.id_token) == 0):
            raise Exception("Invalid Request: " + source.error)
        accessTokenBytes = SlRestUtils.inflate(SlRestUtils.base64UrlDecode(source.id_token))
        serializer = json.decoder.JSONDecoder(object_hook=OAuthResponse.deserialize)
        response = serializer.decode(accessTokenBytes.decode('utf-8'))
        return response

    def requestAccessToken(self, request):
        """ Request an access token for a deployment service.

        -   Parameters:

            request: SlRestDeploymentAccessTokenRequest

        -   Returns:
            SlRestDeploymentAccessTokenResponse
        """
        scopes = "workspace_" + SlRestUtils.htmlEscape(request.workspaceId)
        scopes += " deployment_" + SlRestUtils.htmlEscape(request.deploymentId)
        if (request.deploymentReleaseId is not None and len(request.deploymentReleaseId) != 0):
            scopes += " deployment_" + SlRestUtils.htmlEscape(request.deploymentReleaseId)
        if (request.metricCategory is not None):
            scopes += " category_" + str(request.metricCategory)
        parameters = {
            "grant_type": "password",
            "username": request.username,
            "password": request.password,
            "scope": scopes
        }
        authTag = self._getBaseAuthenticationTag(request.password)
        tokenResponse = SlRestDeploymentAccessTokenResponse(None)
        try:
            response = self._invokeAuth("/Token", parameters, authTag)
            oauth = OAuthResponse.deserialize(response)
            oauth = self._unwrap(oauth)

            tokenResponse.accessTokenResponse = oauth
            tokenResponse.success = oauth.id_token is not None
            return tokenResponse
        except HTTPError as ex:
            tokenResponse.success = False
            tokenResponse.deploymentException = ex
            tokenResponse.errorCode = ex.response.status_code
            tokenResponse.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return tokenResponse
        except Exception as ex:
            tokenResponse.success = False
            tokenResponse.deploymentException = ex
            return tokenResponse

    def refreshAccessToken(self, refreshToken):
        """ Refresh an access token for a deployment service.
        An access token can be refreshed if you were issued a refresh token as part of a previous access
        token request. This allows you to obtain a new access token (and refresh token) when your original access token expired.

        -   Parameters:

            request: SlRestDeploymentRefreshToken

        -   Returns:
            SlRestDeploymentAccessTokenResponse
        """
        parameters = {
            "grant_type": "refresh_token",
            "refresh_token": refreshToken
        }
        self._addRequiredParameters("POST", parameters, self._getAuthServiceUrl() + "/Token")
        authTag = self._getBaseAuthenticationTag(parameters['sign'])
        tokenResponse = SlRestDeploymentAccessTokenResponse(None)

        try:
            response = self._invokeAuth("/Token", parameters, authTag)
            oauth = OAuthResponse.deserialize(response)
            oauth = self._unwrap(oauth)
            tokenResponse.accessTokenResponse = oauth
            tokenResponse.success = oauth.id_token is not None
            return tokenResponse
        except HTTPError as ex:
            tokenResponse.success = False
            tokenResponse.deploymentException = ex
            tokenResponse.errorCode = ex.response.status_code
            tokenResponse.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return tokenResponse
        except Exception as ex:
            tokenResponse.success = False
            tokenResponse.deploymentException = ex
            return tokenResponse


class SlRestClient(SlRestAuthClient):
    """ Create a connection to the deployment service.

     -   Parameters:

            request: SlRestDeploymentConnectionRequest

        -   Returns:
            SlRestDeploymentConnectionResponse
    """
    def connect(self, request):
        reqData = {
            "OperationId": request.operationId,
            "MetricCategory": request.metricCategory,
            "Header": {
                "DeploymentId": request.deploymentId
            }
        }
        if (request.deploymentReleaseId is not None):
            reqData['Header']['DeploymentReleaseId'] = request.deploymentReleaseId

        parameters = {
            "userId": request.username,
            "pwd": request.password,
            "workspaceId": request.workspaceId,
            "reqData": json.dumps(reqData)
        }
        response = SlRestDeploymentConnectionResponse()
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "deployments/connect", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.deploymentId = jsonResponse['Header']['DeploymentId']
            response.deploymentReleaseId = jsonResponse['Header']['DeploymentReleaseId']
            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def disconnect(self, request):
        """ Disconnect from the deployment service.
        Only use this method when using connection sessions instead of tokens

     -   Parameters:

            request: SlRestDeploymentConnectionRequest

        -   Returns:
            SlRestDeploymentDisconnectionResponse
        """
        parameters = {
            "session": request.sessionId
        }
        response = SlRestDeploymentDisconnectionResponse()
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "deployments/disconnect", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def evaluate(self, request):
        """ Evaluate a decision for the specified documents

     -   Parameters:

            request: SlRestDecisionEvaluationRequest

        -   Returns:
            SlRestDecisionEvaluationResponse
        """
        documents = None
        documents = request.documents if isinstance(request.documents, list) else [request.documents]

        reqData = {
            "OperationId": request.operationId,
            "Header": {
                "DecisionId": request.decisionId
            },
            "Body": {
                "Documents": documents
            }
        }
        if (request.accessToken is not None):
            reqData['AccessToken'] = str(request.accessToken)

        if (request.options is not None):
            reqData['Options'] = {
                "OmitDefaultValues": request.options.omitDefaultValues
            }

        parameters = {
            "reqData": json.dumps(reqData)
        }
        if (request.sessionId is not None):
            parameters['session'] = request.sessionId

        response = SlRestDecisionEvaluationResponse()
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "deployments/evaluate", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.deploymentId = jsonResponse['Header']['DeploymentId']
            response.deploymentReleaseId = jsonResponse['Header']['DeploymentReleaseId']
            response.decisionId = jsonResponse['Header']['DecisionId']
            response.transactionTime = jsonResponse['Header']['TransactionTime']

            if ('TransactionTimeMs' in jsonResponse['Header']):
                response.transactionTimeMs = jsonResponse['Header']['TransactionTimeMs']

            if ('Body' in jsonResponse and jsonResponse['Body'] is not None):
                response.documents = jsonResponse['Body']['Documents']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response


class SlRestTaskFlowClient(SlAbstractRestClient):

    def connect(self, request):
        """ Create a connection to the taskflow service.

        -   Parameters:

            request: SlRestDeploymentConnectionRequest

        -   Returns:
            SlRestDeploymentConnectionResponse
        """
        reqData = {
            "OperationId": request.operationId
        }

        parameters = {
            "userId": request.username,
            "pwd": request.password,
            "workspaceId": request.workspaceId,
            "reqData": json.dumps(reqData)
        }
        response = SlRestDeploymentConnectionResponse()
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/connect", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def disconnect(self, request):
        """ Disconnect from the taskflow service.

        -   Parameters:

            request: SlRestDeploymentDisconnectionRequest

        -   Returns:
            SlRestDeploymentDisconnectionResponse
        """
        parameters = {
            "session": request.sessionId
        }
        response = SlRestDeploymentDisconnectionResponse()
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/disconnect", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def execute(self, request):
        """ Triggers the execution of a task flow.

        -   Parameters:

            request: SlRestTaskFlowExecutionRequest

        -   Returns:
            SlRestTaskFlowExecutionResponse
        """
        documents = None
        if (request.documents is not None):
            documents = request.documents if isinstance(request.documents, list) else [request.documents]
        configs = None
        if (request.configs is not None):
            configs = request.configs if isinstance(request.configs, list) else [request.configs]

        reqData = {
            "OperationId": request.operationId,
            "Header": {
                "StateMachineName": request.stateMachineName
            },
            "Body": {
                "TaskFlowDescription": request.taskflowDescription,
                "Documents": documents,
                "Configs": configs
            }
        }

        parameters = {
            "reqData": json.dumps(reqData)
        }
        if (request.sessionId is not None):
            parameters['session'] = request.sessionId

        response = SlRestTaskFlowExecutionResponse(request.sessionId, None)
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/execute", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.stateMachineId = jsonResponse['Header']['StateMachineId']
            response.stateMachineName = jsonResponse['Header']['StateMachineName']

            if ('Body' in jsonResponse and jsonResponse['Body'] is not None):
                response.taskflowId = jsonResponse['Body']['TaskFlowId']
                response.status = jsonResponse['Body']['Status']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def update(self, request):
        """ Update a task flow that is execution.
            This essentially posts events to the task flow so that it is unblocked if it was blocked

        -   Parameters:

            request: SlRestTaskFlowUpdateRequest

        -   Returns:
            SlRestTaskFlowResponse
        """
        reqData = {
            "OperationId": request.operationId,
            "Header": {
                "TaskFlowId": request.taskflowId
            },
            "Body": {
                "Config": request.config
            }
        }

        parameters = {
            "reqData": json.dumps(reqData)
        }
        if (request.sessionId is not None):
            parameters['session'] = request.sessionId

        response = SlRestTaskFlowResponse(request.sessionId, request.taskflowId)
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/update", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.taskflowId = jsonResponse['Header']['TaskFlowId']

            if ('Body' in jsonResponse and jsonResponse['Body'] is not None):
                response.status = jsonResponse['Body']['Status']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def getStatus(self, request):
        """ Get the status of a task flow.

        -   Parameters:

            request: SlRestTaskFlowRequest

        -   Returns:
            SlRestTaskFlowResponse
        """
        reqData = {
            "OperationId": request.operationId,
            "Header": {
                "TaskFlowId": request.taskflowId
            }
        }

        parameters = {
            "reqData": json.dumps(reqData)
        }
        if (request.sessionId is not None):
            parameters['session'] = request.sessionId

        response = SlRestTaskFlowResponse(request.sessionId, request.taskflowId)
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/get-status", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.taskflowId = jsonResponse['Header']['TaskFlowId']

            if ('Body' in jsonResponse and jsonResponse['Body'] is not None):
                response.status = jsonResponse['Body']['Status']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def getResults(self, request):
        """ Get the results of a completed task flow.

        -   Parameters:

            request: SlRestTaskFlowRequest

        -   Returns:
            SlRestTaskFlowResponse
        """
        reqData = {
            "OperationId": request.operationId,
            "Header": {
                "TaskFlowId": request.taskflowId
            }
        }

        parameters = {
            "reqData": json.dumps(reqData)
        }
        if (request.sessionId is not None):
            parameters['session'] = request.sessionId

        response = SlRestTaskFlowResultsResponse(request.sessionId, request.taskflowId)
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/get-results", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.taskflowId = jsonResponse['Header']['TaskFlowId']

            if ('Body' in jsonResponse and jsonResponse['Body'] is not None):
                response.status = jsonResponse['Body']['Status']
                response.tasksResults = jsonResponse['Body']['TasksResults']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def abort(self, request):
        """ Abort a running taskflow.

        -   Parameters:

            request: SlRestTaskFlowRequest

        -   Returns:
            SlRestTaskFlowResponse
        """
        reqData = {
            "OperationId": request.operationId,
            "Header": {
                "TaskFlowId": request.taskflowId
            }
        }

        parameters = {
            "reqData": json.dumps(reqData)
        }
        if (request.sessionId is not None):
            parameters['session'] = request.sessionId

        response = SlRestTaskFlowResponse(request.sessionId, request.taskflowId)
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "taskflow/abort", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            response.sessionId = jsonResponse['Header']['SessionId']
            response.taskflowId = jsonResponse['Header']['TaskFlowId']

            if ('Body' in jsonResponse and jsonResponse['Body'] is not None):
                response.status = jsonResponse['Body']['Status']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response


class SlRestStreamClient(SlRestClient):
    pass

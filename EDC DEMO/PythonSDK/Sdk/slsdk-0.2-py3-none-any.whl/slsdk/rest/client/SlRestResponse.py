class SlRestDeploymentResponse:
    """ Base class for responses from the decision deployment service.

    -   Attributes:

        operationId: integer (Default: 0)
        Operation ID for correlation purposes.

        success: boolean
        Indicates whether the request that originated this response has successfully been processed.

        deploymentException: Exception
        Exception encountered (if any)

        errorCode: string
        Error code

        errorMessage: string
        Additional error message information

        details: string[]
        Error details (if any)

    """
    def __init__(self):
        """Construct an instance of the response class"""
        self.operationId = None
        self.success = False
        self.errorCode = None
        self.errorMessage = None
        self.details = []
        self.deploymentException = None


class SlRestDeploymentToken:
    """ Abstract class for access and refresh tokens."""

    def __init__(self, token):
        """Construct an instance of the response class
        -   Parameters:

            token: string
            String representation of an access token.

        """
        self.token = token

    def __str__(self):
        return self.token


class SlRestDeploymentAccessToken(SlRestDeploymentToken):
    """Access token for access to a deployment service"""
    pass


class SlRestDeploymentRefreshToken(SlRestDeploymentToken):
    """ Refresh token for obtaining new access tokens if your access token expired."""
    pass


class OAuthResponse:
    """ Response information from an OAuth authentication server. """
    def __init__(self):
        self.access_token = None
        self.token_type = None
        self.id_token = None
        self.refresh_token = None
        self.expires_in = None
        self.error = None

    def getDeploymentAccessToken(self):
        if (self.id_token is None or len(self.id_token) == 0):
            return None
        return SlRestDeploymentAccessToken(self.id_token)

    def getDeploymentRefreshToken(self):
        if (self.refresh_token is None or len(self.refresh_token) == 0):
            return None
        return SlRestDeploymentRefreshToken(self.refresh_token)

    def deserialize(data):
        r = OAuthResponse()
        if ('access_token' in data):
            r.access_token = data['access_token']
        if ('token_type' in data):
            r.token_type = data['token_type']
        if ('id_token' in data):
            r.id_token = data['id_token']
        if ('accessrefresh_token_token' in data):
            r.refresh_token = data['refresh_token']
        if ('expires_in' in data):
            r.expires_in = data['expires_in']
        if ('error' in data):
            r.error = data['error']
        return r


class SlRestDeploymentConnectionResponse(SlRestDeploymentResponse):
    """ Response information for a decision deployment service connection.

    -   Attributes:

        sessionId: string
        The session ID for this connection. Use this session ID for evaluation requests.

        deploymentId: string
        Indicates the deployment ID the connection is for.

        deploymentReleaseId: string
        Indicates the release of the deployment the connection is for.

    """

    def __init__(self):
        SlRestDeploymentResponse.__init__(self)
        self.sessionId = None
        self.deploymentId = None
        self.deploymentReleaseId = None


class SlRestDeploymentAccessTokenResponse(SlRestDeploymentConnectionResponse):
    """ Response information for a decision deployment service connection."""

    def __init__(self, tokenResponse):
        SlRestDeploymentConnectionResponse.__init__(self)
        self.accessTokenResponse = tokenResponse

    def getDeploymentAccessToken(self):
        """ The deployment access token.

        Use this access token response to obtain the deployment access token to use for evaluation requests.

        Returns: SlRestDeploymentAccessToken
        """
        return self.accessTokenResponse.getDeploymentAccessToken()


class SlRestDeploymentDisconnectionResponse(SlRestDeploymentResponse):
    """ Response information for disconnecting from a decision deployment service. """
    pass


class SlRestDecisionEvaluationResponse(SlRestDeploymentResponse):
    """ Response information for a decision evaluation request.

    -   Attributes:

        sessionId: string
        The session this response is for (if any)

        deploymentId: string
        The deployment Id of the evaluation.

        deploymentReleaseId: string
        The deployment release Id of the evaluation.

        decisionId: string
        The decision Id requested for the evaluation.

        transactionTime: date
        Start time of the transaction evaluation.

        transactionTimeMs: number
        Total time (in milliseconds) of the transaction.

        documents: Array of JSON objects
        The documents processed by the evaluation of the decision.
    """

    def __init__(self):
        SlRestDeploymentResponse.__init__(self)
        self.sessionId = None
        self.deploymentId = None
        self.deploymentReleaseId = None
        self.decisionId = None
        self.transactionTime = None
        self.transactionTimeMs = None
        self.documents = None


class SlRestDeploymentResponseError(SlRestDeploymentResponse):
    """ Information about a deployment response """

    def __init__(self, success):
        SlRestDeploymentResponse.__init__(self)
        self.success = success


class SlRestDeploymentError(Exception):
    """ Generic deployment or decision evaluation exception.

    -   Attributes:

        deploymentResponse: SlRestDeploymentResponse

    """
    def __init__(self, response):
        Exception.__init__(self, response.errorMessage)
        self.deploymentResponse = SlRestDeploymentResponseError(response.success)
        self.deploymentResponse.deploymentException = response.deploymentException
        self.deploymentResponse.details = response.details
        self.deploymentResponse.errorCode = response.errorCode
        self.deploymentResponse.errorMessage = response.errorMessage


class SlRestTaskFlowResponse(SlRestDeploymentResponse):
    """  Response information for a taskflow request.

    -   Attributes:

        sessionId: string
        taskflowId: string

    """
    def __init__(self, sessionId, taskflowId):
        SlRestDeploymentResponse.__init__(self)
        self.sessionId = sessionId
        self.taskflowId = taskflowId
        self.status = None


class SlRestTaskFlowExecutionResponse(SlRestTaskFlowResponse):
    """ Response information for a taskflow execution request.

    -   Attributes:
        stateMachineId: string
        stateMachineName: string

    """
    def __init__(self, sessionId, taskflowId):
        SlRestTaskFlowResponse.__init__(self, sessionId, taskflowId)
        self.stateMachineId = None
        self.stateMachineName = None


class SlRestTaskFlowResultsResponse(SlRestTaskFlowResponse):
    """ Response information for a taskflow execution request.

    -   Attributes:

        taskResults: object
        The results of a taskflow execution.

    """
    def __init__(self, sessionId, taskflowId):
        SlRestTaskFlowResponse.__init__(self, sessionId, taskflowId)
        self.tasksResults = None

from slsdk.rest.client.SlRestRequest import SlRestDeploymentRequest
from slsdk.rest.client.SlRestResponse import SlRestDeploymentResponse
from slsdk.rest.client.SlRestClient import SlAbstractRestClient
from requests.exceptions import HTTPError
import json


class SlRestDeploymentManagerRequest(SlRestDeploymentRequest):
    """ Base request object for deployment manager requests.

    Context information for a request to establish a connection to a decision deployment service.
    -   Attributes:
        accessToken: SlRestDeploymentAccessToken
        The access token for the request.

    """

    def __init__(self, accessToken):
        """Construct an instance of the request class

        -   Parameters

            accessToken: SlDeploymentAccessToken
            The access token for this request.

        """
        SlRestDeploymentRequest.__init__(self)
        self.accessToken = accessToken


class SlRestDeploymentManagerStatusRequest(SlRestDeploymentManagerRequest):
    """ Request context for obtaining the status of a deployment manager.

    -   Attributes:
        deploymentManager: string
        The name of the deployment manager this request is for.

        workspace: string
        Only retrieve status information for managed deployments in this workspace.

        deploymentId: string
        Only retrieve status information for the specified managed deployment

        deploymentReleaseId: string
        Only retrieve status information for the specified deployment release.

    """
    def __init__(self, accessToken):
        """Construct an instance of the request class

        -   Parameters

            accessToken: SlDeploymentAccessToken
            The access token for this request.

        """
        SlRestDeploymentManagerRequest.__init__(self, accessToken)
        self.deploymentManager = None
        self.workspace = None
        self.deploymentId = None
        self.deploymentReleaseId = None


class SlRestDeploymentManagerResponse(SlRestDeploymentResponse):
    """ Base class for responses for the deployment manager responses."""

    def __init__(self):
        """Construct an instance of the response class"""
        SlRestDeploymentResponse.__init__(self)


class SlRestDeploymentManagerStatusResponse(SlRestDeploymentManagerResponse):
    """ Response for a deployment manager status request.

    -   Attributes:

        isManagedDeployment: boolean
        Indicates whether the deployment is a managed deployment.
        Is true if the access token as part of the status request is a token for a managed deployment.

        deploymentManager: SlRestDeploymentManagerStatus
        Information about the deployment manager's status.

    """

    def __init__(self):
        """Construct an instance of the response class"""
        SlRestDeploymentManagerResponse.__init__(self)
        self.isManagedDeployment = False
        self.deploymentManager = None


class SlRestDeploymentManagerStatus:
    """ Status information for a deployment manager.

    -   Attributes:

        name: string
        The deployment manager's name.

        managedDeployments: SlRestManagedDeploymentStatus[]
        Status for the requested managed deployments.

    """

    def __init__(self):
        """Construct an instance of the status class"""
        self.name = None
        self.managedDeployments = None


class SlRestManagedDeploymentStatus:
    """ Status information for a managed deployment.

    A managed deployment can have both a running and error state at the same time.
    The running state only indicates that the deployment is accepting evaluation requests.
    It is however possible that a newer version of the deployment did not come online (ie. the
    new version has errors, but evaluations are still possible on the older
    version). The deployment information informs you which version of the
    deployment is actually running.

    -   Attributes:

        isRunning: boolean
        Indicator whether the deployment is running.

        workspace: string
        The workspace of the deployment accepting evaluation requests

        deploymentId: string
        The deployment ID of the deployment accepting evaluation requests.

        deploymentReleaseId: string
        The deployment release ID of the deployment accepting evaluation requests.

        errorInfo: SlRestDeploymentErrorInfo
        Error information (if any)

    """

    def __init__(self):
        """Construct an instance of the status class"""
        self.isRunning = False
        self.workspace = None
        self.deploymentId = None
        self.deploymentReleaseId = None
        self.errorInfo = None


class SlRestDeploymentErrorInfo:
    """ Additional error information

    -   Attributes:

        errorCode: string
        The error code.

        errorMessage: string
        Additional error information.

        details: string[]
        Error details (if any).

    """
    def __init__(self):
        """Construct an instance of the error info class"""
        self.errorCode = None
        self.errorMessage = None
        self.details = None


class SlRestDeploymentManagerEventRequest(SlRestDeploymentManagerRequest):
    """ Request context for deployment manager events.

    -   Attributes:

        checkChangeEvent: boolean
        Post a check change event.
        A check change event will trigger the deployment manager's monitor to check for changes explicitly.
        This may trigger updates to the deployment manager if changes have been found.
        Value whether or not to check for changes as part of this event request.

    """

    def __init__(self, accessToken):
        """Construct an instance of the request class

        -   Parameters

            accessToken: SlDeploymentAccessToken
            The access token for this request.

        """
        SlRestDeploymentManagerRequest.__init__(self, accessToken)
        self.checkChangeEvent = False


class SlRestDeploymentManagerEventResponse(SlRestDeploymentManagerResponse):
    """ Response for a deployment manager event request.

    -   Attributes:

        isManagedDeployment: boolean
        Indicates whether the deployment is a managed deployment.
        Is true if the access token as part of the status request is a token for a managed deployment.

    """

    def __init__(self):
        """Construct an instance of the response class"""
        SlRestDeploymentManagerResponse.__init__(self)
        self.isManagedDeployment = False


class SlRestDeploymentManagerClient(SlAbstractRestClient):
    """ Client for interaction with the deployment managers of the decision service."""

    def healthCheck(self, constraint):
        """ Check whether decision service is healthy according to the specified constraint.


        When a constraint violation occurs the health check will return an error code.<br>
        Examples:

        No deployment manager and no deployment may be in an error state:<br>
        $filter=DeploymentManagers/any(m:m/HasErrorState)<br>

        No deployment of the specified deployment manager may be in an error state:<br>
        $filter=DeploymentManagers/any(m:m/Name eq 'Name of DM' and m/HasErrorState)<br>

        At least one deployment must not be in an error state.<br>
        $filter=DeploymentManagers/all(m:m/Deployments/all(d:d/HasErrorState))<br>

        At least one deployment of the specified deployment manager must not be in an error state.<br>
        $filter=DeploymentManagers/any(m:m/Name eq 'Name of DM' and m/Deployments/all(d:d/HasErrorState))<br>

        -   Parameters:

            constraint: string

            Optional constraints to apply as part of the health check operation.

        -   Returns:

            HTTP Status Code

        """
        parameters = dict()
        self._addCommonParameters(parameters)

        if (constraint is not None):
            parameters['constraint'] = constraint

        return self._invokeHealthCheck("GET", "/deployments/health-check", parameters)

    def requestDeploymentManagerStatus(self, request):
        """ Request detailed status information for a deployment manager specified by the request.

        -   Parameters:

            request: SlRestDeploymentManagerStatusRequest

            The request is required to specify an access token and will return information about
            the deployment manager that is associate with the token.

        -   Returns:
            SlRestDeploymentManagerStatusResponse

        """
        response = SlRestDeploymentManagerStatusResponse()
        if (request.accessToken is None):
            response.success = False
            response.errorMessage = "No access token specified"
            return response

        reqData = {
            "OperationId": request.operationId,
            "AccessToken": str(request.accessToken),
        }
        if (request.deploymentManager is not None):
            reqData['DeploymentManager'] = request.deploymentManager

        if (request.workspace is not None):
            reqData['Workspace'] = request.workspace

        if (request.deploymentId is not None):
            reqData['DeploymentId'] = request.deploymentId

        if (request.deploymentReleaseId is not None):
            reqData['DeploymentReleaseId'] = request.deploymentReleaseId

        parameters = {
            "reqData": json.dumps(reqData)
        }
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "deployments/deployment-manager-status", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response
            deploymentManager = SlRestDeploymentManagerStatus()
            if (jsonResponse['DeploymentManager'] is not None):
                dm = jsonResponse['DeploymentManager']
                deploymentManager.name = dm['Name']

                if (dm['ManagedDeployments'] is not None):
                    deployments = dm['ManagedDeployments']
                    managedDeployments = []

                    for d in deployments:
                        deployment = SlRestManagedDeploymentStatus()
                        if (d['ErrorInfo'] is not None):
                            errorInfo = SlRestDeploymentErrorInfo()
                            errorInfo.errorCode = d['ErrorInfo']['ErrorCode']
                            errorInfo.errorMessage = d['ErrorInfo']['ErrorMessage']
                            errorInfo.details = d['ErrorInfo']['details']
                            deployment.errorInfo = errorInfo

                        deployment.isRunning = d['IsRunning']
                        deployment.workspace = d['Workspace']
                        deployment.deploymentId = d['Deployment']
                        deployment.deploymentReleaseId = d['DeploymentRelease']

                        managedDeployments.append(deployment)

                    deploymentManager.managedDeployments = managedDeployments
                response.deploymentManager = deploymentManager
                response.isManagedDeployment = jsonResponse['IsManagedDeployment']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

    def postDeploymentManagerEvent(self, request):
        """  Post an event to the deployment manager.

        The deployment manager service will process the requested event. Depending on the type of the event this may
        be an asynchronous or synchronous operation.

        -   Parameters

            request: SlRestDeploymentManagerEventRequest
            Event information

        -   Returns SlRestDeploymentManagerEventResponse

        """
        response = SlRestDeploymentManagerEventResponse()
        if (request.accessToken is None):
            response.success = False
            response.errorMessage = "No access token specified"
            return response

        reqData = {
            "OperationId": request.operationId,
            "AccessToken": str(request.accessToken),
        }
        if (request.checkChangeEvent is True):
            reqData['CheckChangeEvent'] = True

        parameters = {
            "reqData": json.dumps(reqData)
        }
        response.operationId = request.operationId
        try:
            jsonResponse = self._invoke("POST", "deployments/deployment-manager-event", parameters)
            SlAbstractRestClient._handleResponseStatus(self, response, jsonResponse)
            if (response.success is False):
                return response

            response.isManagedDeployment = jsonResponse['IsManagedDeployment']

            return response
        except HTTPError as ex:
            response.success = False
            response.deploymentException = ex
            response.errorCode = ex.response.status_code
            response.errorMessage = str.format("[{0}] {1}", ex.response.status_code, ex.response.reason)
            return response
        except Exception as ex:
            response.success = False
            response.deploymentException = ex
            return response

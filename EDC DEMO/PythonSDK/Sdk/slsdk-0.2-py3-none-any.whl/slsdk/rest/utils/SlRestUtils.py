import datetime
from urllib.parse import urlencode
from urllib.parse import quote
from urllib.parse import urlparse
import hmac
import hashlib
import base64
import zlib


class SlRestUtils:

    def getFormattedCurrentTimestampISO8601():
        return datetime.datetime.utcnow().isoformat() + "Z"

    def signQueryParameters(method, host, endpointUri, key, qryParameters):
        qryParameters['reqTime'] = SlRestUtils.getFormattedCurrentTimestampISO8601()
        dataStr = method + '\n' + host + '\n' + endpointUri + '\n' + urlencode(sorted(qryParameters.items()), quote_via=quote)
        # print (dataStr)
        data = dataStr.encode('utf-8')
        digest = hmac.new(key.encode('utf-8'), msg=data, digestmod=hashlib.sha256).digest()
        signature = base64.b64encode(digest).decode()
        qryParameters['sign'] = signature

    def getParametersAsString(qryParameters):
        return urlencode(sorted(qryParameters.items()), quote_via=quote)

    def getAuthority(url):
        return urlparse(url).netloc

    def getEndpoint(url):
        return urlparse(url).path

    def hmacSign(data, key, alg):
        # h = hmac.digest(key, data, hashlib.sha256)
        h = hmac.new(key, msg=data, digestmod=hashlib.sha256).digest()
        return base64.b64encode(h)

    def getDerivedBytes(password, salt, iterations, dklen):
        pwdHash = SlRestUtils.hmacSign(salt, password, 'sha256')
        return hashlib.pbkdf2_hmac('sha1', password, pwdHash, iterations, dklen)

    def htmlEscape(input):
        return quote(input)

    def base64UrlEncode(input):
        output = base64.urlsafe_b64encode(input)
        return output.decode('utf-8').split('=')[0]

    def base64UrlDecode(input):
        output = input
        output = output.replace('-', '+')
        output = output.replace('_', '/')
        pad = len(output) % 4
        if (pad == 0):
            return base64.b64decode(output)
        elif (pad == 2):
            return base64.b64decode(output + "==")
        elif (pad == 3):
            return base64.b64decode(output + "=")
        else:
            raise Exception("Illegal base64url string!")

    def getBaseAuthenticationTag(appId, appKey, pw):
        derived = SlRestUtils.getDerivedBytes(appKey, pw, 1000, 16)
        authTag = SlRestUtils.base64UrlEncode(derived)
        return base64.b64encode((appId + ":" + authTag).encode('utf-8')).decode('utf-8')

    def inflate(data):
        return zlib.decompress(data, -zlib.MAX_WBITS)

    def deflate(data):
        zipped = zlib.compress(data)
        return zipped[2:-4]
